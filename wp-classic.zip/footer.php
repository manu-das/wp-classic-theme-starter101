<footer class="footer">
  

</footer>
   <!-- <span>Copyright © <script>document.write(new Date().getFullYear())</script> your site name &nbsp;| -->
  <!-------- footer end-------->
 <?php wp_footer(); ?>
  
</body>

</html>


      
            

            